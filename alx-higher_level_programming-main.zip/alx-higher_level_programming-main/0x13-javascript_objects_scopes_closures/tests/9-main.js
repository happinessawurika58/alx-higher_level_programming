#!/usr/bin/node
const logMe = require('../9-logme').logMe;

logMe('Hello');
logMe('Best');
logMe('School');
