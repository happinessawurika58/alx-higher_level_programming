#!/usr/bin/python3
"""Define a class Square."""


class Square:
    """Represent a square."""
    pass
