# 0x02. Python - import & modules

In this project, I am introduced to python modules.

## Learnt
- How to import functions from another files
- How to use imported functions
- How to create a python module
- How to use the built-in funtion `dir()`
- How to prevent code in your script from being executed when imported
- How to use commandline arguments in Python programs

## Resources
- [Python Documentation](https://docs.python.org/3/tutorial/modules.html)