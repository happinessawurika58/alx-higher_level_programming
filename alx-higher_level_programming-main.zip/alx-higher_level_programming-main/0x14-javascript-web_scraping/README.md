# 0x14. JavaScript - Web scraping
[![js-semistandard-style](https://raw.githubusercontent.com/standard/semistandard/master/badge.svg)](https://github.com/standard/semistandard)

In this project, I am introduced to JavaScript web scraping using the `request` and `fs` modules