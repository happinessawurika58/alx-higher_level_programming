# 0x10-python_network_0
In this project I learnt about:
- What a URL is
- What HTTP is
- How to read a URL
- The scheme for a HTTP URL
- What a domain name is
- What a subdomain is
- How to define a port number in a URL
- What a querry staring is
- WHat a HTTP request is 
- What an HTTP response is
- What HTTP headers are
- What the HTTP message body is
- What an HTTP request method is
- What an HTTP response status code is
- What an HTTP Cookie is
- How to make a request with cURL
- What happens when you type google.com in your browser (Application level)

## Resources used
- [developer.mozilla.org](https://developer.mozilla.org/en-US/docs/Web/HTTP/Cookies)
- [www3.ntu.edu.sg](https://www3.ntu.edu.sg/home/ehchua/programming/webprogramming/HTTP_Basics.html)