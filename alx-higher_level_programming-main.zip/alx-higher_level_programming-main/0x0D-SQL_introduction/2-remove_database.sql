-- deletes the database hbtn_0c_0 in my MySQL server
DROP DATABASE IF EXISTS `hbtn_0c_0`;
