$('DIV#update_header').click(function () {
  $('HEADER').text('New Header!!!');
});
