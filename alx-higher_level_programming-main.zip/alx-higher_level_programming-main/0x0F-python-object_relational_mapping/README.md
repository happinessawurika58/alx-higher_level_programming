# 0x0F. Python - Object-relational mapping

In this project, I learnt to use Object Relational Mappers in place of actual SQL with the SQLAlchemy python module.

## Resources
- [fullstackpython.com](https://www.fullstackpython.com/object-relational-mappers-orms.html)
- [edureka](https://www.youtube.com/watch?v=g60QghtJmjY)
- [overiq.com](https://overiq.com/sqlalchemy-101/)