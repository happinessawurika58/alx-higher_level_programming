#!/usr/bin/python3
number = 98
print("{:d} Battery street".format(number))
