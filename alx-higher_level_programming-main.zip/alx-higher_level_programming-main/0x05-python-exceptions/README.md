# Python - Exceptions

Python exceptions are a life savior.

In this project, I learnt:
- What’s the difference between errors and exceptions
- What are exceptions and how to use them
- When do we need to use exceptions
- How to correctly handle an exception
- What’s the purpose of catching exceptions
- How to raise a builtin exception
- When do we need to implement a clean-up action after an exception

## Resources
[Edureka](https://www.youtube.com/watch?v=NMTEjQ8-AJMf )